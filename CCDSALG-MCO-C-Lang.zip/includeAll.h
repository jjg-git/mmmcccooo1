#ifndef INCLUDEALL_H
#define INCLUDEALL_H

#include "essentials.h"
#include "structs.h"
#include "sorting.h"

#endif
