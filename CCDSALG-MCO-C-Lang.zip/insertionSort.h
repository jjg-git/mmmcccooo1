#ifndef INSERTIONSORT_H
#define INSERTIONSORT_H

#include "defines.h"

void insertionSort();

#endif // ifndef INSERTIONSORT_H
