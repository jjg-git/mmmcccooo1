#ifndef DEFINES_H
#define DEFINES_H

#define START_ABC A   // uppercase a-z
#define END_ABC Z
#define START_LABC a  // lowercase a-z
#define END_LABC z

#define MAX_STRING 50

typedef char String[MAX_STRING];

#endif // ifndef DEFINES_H
