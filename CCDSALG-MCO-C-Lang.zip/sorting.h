#ifndef SORTING_H
#define SORTING_H

#include "defines.h"

#include "insertionSort.h"
#include "quickSort.h"

#endif // ifndef SORTING_H
