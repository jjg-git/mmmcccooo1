#ifndef STRUCTS_H
#define STRUCTS_H

#include "defines.h"

#endif
