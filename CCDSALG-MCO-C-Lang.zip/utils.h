#ifndef UTILS_H
#define UTILS_H

#include "defines.h"

void stringSuffix(String from, String to, int idx);

#endif // ifndef UTILS_H
