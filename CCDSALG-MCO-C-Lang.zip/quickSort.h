#ifndef QUICKSORT_H
#define QUICKSORT_H

#include "defines.h"

void quickSort();
void partition();

#endif // ifndef QUICKSORT_H
